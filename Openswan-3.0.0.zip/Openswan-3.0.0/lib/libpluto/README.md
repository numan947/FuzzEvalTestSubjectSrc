The libpluto library contains core pieces of pluto which have usually
been seperated out of pluto itself in order to permit easier unit testing.
It is entirely possible that libpluto continues to depend upon core
parts of pluto --- that's not a desireable state, but it will be an
acceptable state for awhile.
