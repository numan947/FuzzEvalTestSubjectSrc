#ifndef _READWHACKMSG_H
#define _READWHACKMSG_H

extern int readwhackmsg(char *infile);

#endif /* _READWHACKMSG_H */

