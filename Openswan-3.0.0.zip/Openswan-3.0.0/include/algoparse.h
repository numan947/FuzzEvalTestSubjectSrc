#ifndef _ALGOPARSE_H
#define _ALGOPARSE_H

extern void init_crypto_groups(void);

#endif
